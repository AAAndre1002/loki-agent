# Loki Agent (Android) — versão 0.3.0

Assistente Android open source com voz, ações locais explícitas, controlos de acessibilidade opcionais e ligação a modelos compatíveis com Ollama.

**Código-fonte completo:** [Loki-Agent-Android-v0.3.0.zip](./Loki-Agent-Android-v0.3.0.zip)

## O que faz

- Reconhece voz em português e responde por voz.
- Abre apps pelo nome visível no telemóvel, além de YouTube, WhatsApp, Maps, Chrome e Definições.
- Pesquisa na web e diz as horas.
- Opcionalmente, liga-se a Ollama ou a outro endpoint compatível com a API OpenAI.
- Com o Serviço de Acessibilidade autorizado: mostra um microfone flutuante para ler texto acessível, subir/descer, voltar, ir ao ecrã inicial e tocar num elemento indicado. Cada toque pede confirmação.
- Nunca transforma a resposta do modelo em comandos executáveis.

## Abrir no Android Studio

1. Extrai o ZIP e abre a pasta `LokiAgent` no Android Studio.
2. Instala JDK 17; aceita o download do Android Gradle Plugin e Android SDK 35.
3. Liga o telemóvel por USB (depuração USB) ou usa um emulador e carrega em **Run**.
4. Permite o microfone quando a app pedir.

## Criar APK

No Android Studio, usa **Build → Build Bundle(s) / APK(s) → Build APK(s)**. O APK de depuração sai em `app/build/outputs/apk/debug/app-debug.apk`.

No GitHub, o workflow **Build Android APK** também compila o projeto; quando terminar, descarrega o artefacto APK na execução em **Actions**. É um APK debug instalável para testes, não um APK de publicação assinado.

## Ligar a Ollama

Na app, configura o URL completo de `/v1/chat/completions`, por exemplo `http://192.168.1.20:11434/v1/chat/completions`, e o nome do modelo instalado, como `qwen2.5:3b`. O telemóvel e o servidor têm de comunicar na mesma rede. Não exponhas Ollama diretamente à Internet; usa HTTPS e autenticação para qualquer acesso remoto.

## Controlos de acessibilidade

1. Toca em **Ativar / gerir acessibilidade** e ativa **Loki Agent — controlos autorizados** nas Definições.
2. Com outra app aberta, toca no microfone flutuante e diz, por exemplo: “lê o ecrã”, “desce”, “voltar” ou “toca em pesquisar”.
3. Confirma no diálogo antes de cada toque.

O serviço pode ler o texto que o Android expõe enquanto está ativo. O protótipo não guarda nem envia esse texto ao modelo. Algumas apps ocultam conteúdo ou bloqueiam controlos. Não há palavra de ativação nem escuta contínua.

## Segurança e licença

O modelo só gera respostas em texto; chamadas, mensagens e ações financeiras não são executadas automaticamente. A permissão de Acessibilidade é opcional e requer ativação explícita pelo utilizador. Licença MIT — ver `LICENSE`.
