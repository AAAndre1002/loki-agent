package pt.neodriftcode.lokiagent

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.TextView
import android.widget.Toast
import java.text.Normalizer
import java.util.Locale

/**
 * User-enabled accessibility bridge. A floating mic opens the app's regular
 * voice screen; only explicit user commands are handled, never model output.
 */
class LokiAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var micBubble: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        active = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createMicBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (active === this) active = null
        micBubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }
        micBubble = null
        super.onDestroy()
    }

    private fun createMicBubble() {
        val bubble = TextView(this).apply {
            text = "🎙"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(83, 109, 254))
                setStroke(dp(2), Color.WHITE)
            }
            contentDescription = "Loki Agent: tocar para dar um comando de voz"
            setOnClickListener {
                val intent = Intent(this@LokiAccessibilityService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    putExtra(MainActivity.EXTRA_START_VOICE, true)
                }
                try { startActivity(intent) }
                catch (_: Exception) { Toast.makeText(this@LokiAccessibilityService, "Abre a app Loki Agent e tenta novamente.", Toast.LENGTH_SHORT).show() }
            }
        }
        val params = WindowManager.LayoutParams(
            dp(60), dp(60),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(12)
        }
        try {
            windowManager?.addView(bubble, params)
            micBubble = bubble
        } catch (_: Exception) {
            Toast.makeText(this, "Não consegui mostrar o microfone flutuante.", Toast.LENGTH_LONG).show()
        }
    }

    fun readCurrentScreen(): String {
        val root = targetRoot() ?: return "Não encontrei outra app aberta com texto acessível."
        val lines = mutableListOf<String>()
        collectText(root, lines, 0)
        val result = lines.distinct().joinToString(". ").take(MAX_READ_CHARS)
        return if (result.isBlank()) "Não encontrei texto acessível no ecrã atual." else result
    }

    fun scroll(forward: Boolean): Boolean {
        val root = targetRoot() ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return performOnScrollable(root, action, 0)
    }

    fun clickText(label: String): Boolean {
        if (normalize(label).length < 2) return false
        val root = targetRoot() ?: return false
        val match = findMatchingNode(root, normalize(label), 0) ?: return false
        var candidate: AccessibilityNodeInfo? = match
        var depth = 0
        while (candidate != null && depth < 8) {
            if (candidate.isClickable && candidate.isEnabled && candidate.isVisibleToUser) {
                return candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            candidate = candidate.parent
            depth++
        }
        return false
    }

    /** Uses the underlying non-Loki Agent application window while voice UI is open. */
    private fun targetRoot(): AccessibilityNodeInfo? {
        val appWindow = windows.firstOrNull { window ->
            window.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                window.root?.packageName?.toString() != packageName
        }
        if (appWindow?.root != null) return appWindow.root
        return rootInActiveWindow?.takeIf { it.packageName?.toString() != packageName }
    }

    private fun collectText(node: AccessibilityNodeInfo, output: MutableList<String>, depth: Int) {
        if (depth > MAX_DEPTH || output.size >= MAX_NODES) return
        if (node.isVisibleToUser) {
            val text = node.text?.toString()?.trim().orEmpty()
            val description = node.contentDescription?.toString()?.trim().orEmpty()
            if (text.isNotBlank()) output.add(text) else if (description.isNotBlank()) output.add(description)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, output, depth + 1) }
            if (output.size >= MAX_NODES) return
        }
    }

    private fun performOnScrollable(node: AccessibilityNodeInfo, action: Int, depth: Int): Boolean {
        if (depth > MAX_DEPTH) return false
        if (node.isVisibleToUser && node.isScrollable && node.isEnabled && node.performAction(action)) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (performOnScrollable(child, action, depth + 1)) return true
        }
        return false
    }

    private fun findMatchingNode(node: AccessibilityNodeInfo, needle: String, depth: Int): AccessibilityNodeInfo? {
        if (depth > MAX_DEPTH || !node.isVisibleToUser) return null
        val text = normalize(node.text?.toString().orEmpty())
        val description = normalize(node.contentDescription?.toString().orEmpty())
        if (node.isEnabled && (text.contains(needle) || description.contains(needle))) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findMatchingNode(child, needle, depth + 1)?.let { return it }
        }
        return null
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "").trim()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        @Volatile var active: LokiAccessibilityService? = null
            private set
        private const val MAX_DEPTH = 40
        private const val MAX_NODES = 80
        private const val MAX_READ_CHARS = 2200
    }
}
