package pt.neodriftcode.lokiagent

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Loki Agent 0.2 — voice-first Android assistant starter.
 * Direct commands run locally. Other prompts can be sent to an optional
 * OpenAI-compatible endpoint (e.g. Ollama's /v1/chat/completions).
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var input: EditText
    private lateinit var endpointInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var answer: TextView
    private lateinit var speakToggle: Button
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("lokiagent", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        loadSettings()
        if (intent.getBooleanExtra(EXTRA_START_VOICE, false)) window.decorView.post { listen() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_START_VOICE, false)) window.decorView.post { listen() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(0xFF10131C.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("LOKI AGENT", 26f, 0xFFFFFFFF.toInt()))
        content.addView(label("Assistente Android open source · protótipo 0.2", 14f, 0xFFB8C0D9.toInt()))
        content.addView(space(18))
        content.addView(label("O que queres fazer?", 16f, 0xFFFFFFFF.toInt()))
        input = EditText(this).apply {
            hint = "Ex.: abre o YouTube ou pergunta algo ao modelo"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA3BC.toInt())
            setSingleLine(false)
            minLines = 2
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFF202638.toInt())
        }
        content.addView(input, matchWrap())

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mic = Button(this).apply { text = "🎙 Falar"; setOnClickListener { listen() } }
        buttons.addView(mic, weighted())
        val run = Button(this).apply { text = "Executar"; setOnClickListener { submitPrompt(input.text.toString()) } }
        buttons.addView(run, weighted())
        content.addView(buttons)

        answer = label("Pronto. Experimenta ‘que horas são’ ou ‘abre o YouTube’.", 15f, 0xFFE5E9F5.toInt())
        answer.setPadding(0, dp(16), 0, dp(18))
        content.addView(answer)

        content.addView(label("Controlos de acessibilidade (opcionais)", 15f, 0xFFFFFFFF.toInt()))
        content.addView(label("Depois de ativares o serviço nas Definições do Android, podes pedir para ler o ecrã, subir/descer, voltar ou tocar num elemento. Cada toque pede confirmação; a IA não executa ações.", 12f, 0xFFB8C0D9.toInt()))
        content.addView(Button(this).apply {
            text = "Ativar / gerir acessibilidade"
            setOnClickListener { requestAccessibilitySetup() }
        })

        content.addView(label("Modelo IA opcional (compatível com API OpenAI)", 15f, 0xFFFFFFFF.toInt()))
        content.addView(label("Para Ollama num computador na mesma rede, usa o endereço do computador, por exemplo http://192.168.1.20:11434/v1/chat/completions. Não uses 127.0.0.1 no telemóvel.", 12f, 0xFFB8C0D9.toInt()))
        endpointInput = EditText(this).apply {
            hint = "URL do endpoint (opcional)"
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9AA3BC.toInt())
            setSingleLine(true); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(0xFF202638.toInt())
        }
        content.addView(endpointInput, matchWrap())
        modelInput = EditText(this).apply {
            hint = "Nome do modelo, ex.: qwen2.5:3b"
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9AA3BC.toInt())
            setSingleLine(true); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(0xFF202638.toInt())
        }
        content.addView(modelInput, matchWrap())
        content.addView(Button(this).apply {
            text = "Guardar configuração"
            setOnClickListener {
                prefs.edit().putString("endpoint", endpointInput.text.toString().trim())
                    .putString("model", modelInput.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Configuração guardada", Toast.LENGTH_SHORT).show()
            }
        })
        content.addView(label("Privacidade: sem endpoint, os pedidos não são enviados para um modelo externo. Com endpoint, o texto do pedido é enviado para esse servidor. A voz é reconhecida pelo serviço de voz configurado no Android.", 12f, 0xFF9AA3BC.toInt()))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun loadSettings() {
        endpointInput.setText(prefs.getString("endpoint", ""))
        modelInput.setText(prefs.getString("model", "qwen2.5:3b"))
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Diz o que queres fazer")
        }
        try { startActivityForResult(intent, REQUEST_SPEECH) }
        catch (_: ActivityNotFoundException) {
            showAnswer("Não encontrei um serviço de reconhecimento de voz neste Android.", true)
        }
    }

    @Deprecated("Deprecated by Android, retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken)
            if (spoken.isNotBlank()) submitPrompt(spoken)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_ACCESSIBILITY_AUDIO) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) openAccessibilitySettings()
            else showAnswer("Para usar o microfone flutuante, permite o acesso ao microfone.", true)
            return
        }
        if (requestCode == REQUEST_AUDIO && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else if (requestCode == REQUEST_AUDIO) showAnswer("Sem a permissão do microfone, não consigo ouvir comandos.", true)
    }

    private fun requestAccessibilitySetup() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_ACCESSIBILITY_AUDIO)
        } else openAccessibilitySettings()
    }

    private fun openAccessibilitySettings() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (_: Exception) { showAnswer("Abre Definições → Acessibilidade e ativa ‘Loki Agent — controlos autorizados’.", true) }
    }

    private fun submitPrompt(raw: String) {
        val prompt = raw.trim()
        if (prompt.isEmpty()) { showAnswer("Escreve ou dita um pedido.", false); return }
        input.setText(prompt)
        if (handleAccessibilityCommand(prompt)) return
        val direct = runDirectCommand(prompt)
        if (direct != null) { showAnswer(direct.first, direct.second); return }

        val endpoint = endpointInput.text.toString().trim()
        val model = modelInput.text.toString().trim().ifBlank { "qwen2.5:3b" }
        if (endpoint.isBlank()) {
            showAnswer("Ainda não configurei um modelo IA. Os comandos locais disponíveis são: abrir apps conhecidas, pesquisar na web e dizer as horas. Para perguntas livres, configura um endpoint compatível com OpenAI, por exemplo Ollama.", true)
            return
        }
        showAnswer("A pensar…", false)
        worker.execute {
            val result = askModel(endpoint, model, prompt)
            runOnUiThread { showAnswer(result, true) }
        }
    }

    /** Accessibility commands come only from the user's explicit text/voice input. */
    private fun handleAccessibilityCommand(raw: String): Boolean {
        val text = normalize(raw)
        val service = LokiAccessibilityService.active
        if (text in setOf("le o ecra", "ler o ecra", "le o que esta no ecra", "le o ecrã")) {
            if (service == null) {
                showAnswer("Ativa primeiro o serviço em ‘Ativar / gerir acessibilidade’.", true)
            } else showAnswer(service.readCurrentScreen(), true)
            return true
        }
        if (text in setOf("desce", "descer", "rola para baixo", "desce a pagina", "scroll down")) {
            if (service == null) showAnswer("Ativa primeiro o serviço de acessibilidade.", true)
            else showAnswer(if (service.scroll(true)) "A descer a página." else "Não encontrei uma área que possa descer.", true)
            return true
        }
        if (text in setOf("sobe", "subir", "rola para cima", "sobe a pagina", "scroll up")) {
            if (service == null) showAnswer("Ativa primeiro o serviço de acessibilidade.", true)
            else showAnswer(if (service.scroll(false)) "A subir a página." else "Não encontrei uma área que possa subir.", true)
            return true
        }
        if (text in setOf("voltar", "volta atras", "retroceder", "back")) {
            if (service == null) showAnswer("Ativa primeiro o serviço de acessibilidade.", true)
            else showAnswer(if (service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)) "Voltei atrás." else "Não consegui voltar atrás.", true)
            return true
        }
        if (text in setOf("ir para inicio", "ecra inicial", "home", "voltar ao inicio")) {
            if (service == null) showAnswer("Ativa primeiro o serviço de acessibilidade.", true)
            else showAnswer(if (service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)) "A mostrar o ecrã inicial." else "Não consegui abrir o ecrã inicial.", true)
            return true
        }
        val clickPrefixes = listOf("toca em ", "toca no ", "toca na ", "carrega em ", "clica em ")
        val clickPrefix = clickPrefixes.firstOrNull { text.startsWith(it) }
        if (clickPrefix != null) {
            val target = text.removePrefix(clickPrefix).trim()
            if (target.isBlank()) { showAnswer("Diz o texto do elemento em que queres tocar.", true); return true }
            if (service == null) { showAnswer("Ativa primeiro o serviço de acessibilidade.", true); return true }
            AlertDialog.Builder(this)
                .setTitle("Confirmar toque")
                .setMessage("Queres tocar em ‘$target’ na app que está aberta? Isto pode ativar um botão ou abrir um link.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Confirmar") { _, _ ->
                    val current = LokiAccessibilityService.active
                    showAnswer(if (current?.clickText(target) == true) "Toque executado em ‘$target’." else "Não encontrei um elemento visível com esse texto.", true)
                }
                .show()
            return true
        }
        return false
    }

    /** Only explicit, allow-listed local commands are executed in this MVP. */
    private fun runDirectCommand(raw: String): Pair<String, Boolean>? {
        val text = normalize(raw)
        if (text.contains("horas") || text == "que horas sao") {
            val time = SimpleDateFormat("HH:mm", Locale("pt", "PT")).format(Date())
            return Pair("São $time.", true)
        }
        val openPrefixes = listOf("abre ", "abrir ", "open ", "abre a ", "abre o ")
        val prefix = openPrefixes.firstOrNull { text.startsWith(it) }
        if (prefix != null) {
            val target = text.removePrefix(prefix).trim()
            val match = appTargets.firstOrNull { target.contains(it.first) }
            if (match != null) {
                val launch = packageManager.getLaunchIntentForPackage(match.second)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                    return Pair("A abrir ${match.third}.", true)
                }
                return Pair("Não encontrei ${match.third} instalado neste telemóvel.", true)
            }
            return Pair("Ainda não tenho essa app na lista segura. Nesta versão consigo abrir YouTube, WhatsApp, Maps, Chrome e Definições.", true)
        }
        if (text.startsWith("pesquisa ") || text.startsWith("pesquisar ") || text.startsWith("procura ")) {
            val query = raw.substringAfter(' ').trim()
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            return Pair("A pesquisar na web por: $query", true)
        }
        return null
    }

    private fun askModel(endpoint: String, model: String, prompt: String): String {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject()
                .put("model", model)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "És um assistente útil. Responde em português europeu. Não afirmes que executaste ações no telemóvel; só a app pode executar comandos explícitos e permitidos."))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                .put("stream", false)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) return "O servidor devolveu erro HTTP $code: ${response.take(400)}"
            val json = JSONObject(response)
            json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() }
                ?: json.optString("response").takeIf { it.isNotBlank() }
                ?: "Recebi uma resposta, mas não reconheci o formato. Confirma que o endpoint é compatível com OpenAI."
        } catch (e: Exception) {
            "Não consegui contactar o modelo: ${e.localizedMessage ?: "verifica o endereço e a rede"}"
        } finally { connection?.disconnect() }
    }

    private fun showAnswer(text: String, speak: Boolean) {
        answer.text = text
        if (speak && ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lokiagent-answer")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("pt", "PT")
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); worker.shutdownNow()
        super.onDestroy()
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(0, dp(5), 0, dp(5))
    }
    private fun space(height: Int) = TextView(this).apply { this.height = dp(height) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun weighted() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    companion object {
        const val EXTRA_START_VOICE = "pt.neodriftcode.lokiagent.START_VOICE"
        private const val REQUEST_AUDIO = 21
        private const val REQUEST_SPEECH = 22
        private const val REQUEST_ACCESSIBILITY_AUDIO = 23
        private val appTargets = listOf(
            Triple("youtube", "com.google.android.youtube", "o YouTube"),
            Triple("whatsapp", "com.whatsapp", "o WhatsApp"),
            Triple("maps", "com.google.android.apps.maps", "o Google Maps"),
            Triple("chrome", "com.android.chrome", "o Chrome"),
            Triple("definicoes", "com.android.settings", "as Definições"),
            Triple("configuracoes", "com.android.settings", "as Definições"),
            Triple("settings", "com.android.settings", "as Definições")
        )
    }
}
